
# HWP 파일 포맷 구조 분석 (개발자용)

## I. 공통 자료형 (Data Types)

HWP 파일은 리틀 엔디언(Little-endian) 형태로 저장됩니다.

| 자료형 (Type) | 길이 (Bytes) | HWP 버전 | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| **BYTE** (UINT8) | 1 | 5.0 | 부호 없는 8비트 정수 (0 ~ 255) | |
| **WORD** (UINT16) | 2 | 5.0 | 부호 없는 16비트 정수 | |
| **DWORD** (UINT32) | 4 | 5.0 | 부호 없는 32비트 정수 | |
| **WCHAR** | 2 | 5.0 | 유니코드 기반 문자 (UTF-16LE) | |
| **HWPUNIT** (UINT32) | 4 | 5.0 | 글 내부 단위 (1/7200인치) | |
| **SHWPUNIT** (INT32) | 4 | 5.0 | 부호 있는 글 내부 단위 (1/7200인치) | |
| **COLORREF** | 4 | 5.0 | RGB 값 (0x00bbggrr) | |
| **hchar** | 2 | 3.x | 글 내부 코드로 표현된 문자 (2바이트 고정 길이) | |
| **hunit** | 2 | 3.x | 글 내부 단위 (1/1800인치) | |
| **dword** | 4 | 3.x | 32비트 unsigned long | |

---

## II. 글 문서 파일 형식 5.0 (Compound File / Record 기반)

HWP 5.0 형식은 복합 파일(Compound File) 구조이며, 내부 데이터는 **데이터 레코드(Data Record)** 형태로 구성됩니다. 레코드 헤더는 **32비트**로 Tag ID (10비트), Level (10비트), Size (12비트)로 구성됩니다.

### 1. FileHeader 스트림 (고정 길이: 256 Bytes)

| 오프셋 (Offset) | 자료형 (Type) | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | BYTE array | **32** | Signature: "HWP Document File" | |
| 32 | DWORD | **4** | 파일 버전 (0xMMnnPPrr) | |
| 36 | DWORD | **4** | 속성 (압축/암호화/DRM 등 플래그) | |
| 40 | DWORD | **4** | 속성 2 (CCL/복제 제한 플래그) | |
| 44 | DWORD | **4** | EncryptVersion | |
| 48 | BYTE | **1** | KOGL 라이선스 지원 국가 | |
| 49 | BYTE array | **207** | 예약 영역 | |
| **총 길이** | | **256** | | |

### 2. DocInfo 스트림: 주요 레코드 상세

#### 2.1. 문서 속성 (HWPTAG_DOCUMENT_PROPERTIES, Tag ID: 0x010)

| 오프셋 (Record Start 기준) | 자료형 | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | UINT16 | 2 | 구역 개수 | |
| 2 ~ 14 | UINT16 array | 12 | 페이지, 각주, 미주, 그림, 표, 수식 시작 번호 | |
| 14 | UINT32 | 4 | 커서 위치: 리스트 아이디 | |
| 18 | UINT32 | 4 | 커서 위치: 문단 아이디 | |
| 22 | UINT32 | 4 | 커서 위치: 글자 단위 위치 | |
| **총 길이** | | **26** | | |

#### 2.2. 아이디 매핑 헤더 (HWPTAG_ID_MAPPINGS, Tag ID: 0x011)

| 오프셋 | 자료형 | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | INT32 array | **72** | 글꼴, 테두리, 스타일 등 18개 항목의 아이디 매핑 개수 | |
| **총 길이** | | **72** | | |

### 3. BodyText 스트림: 본문 레코드 상세

#### 3.1. 문단 헤더 (HWPTAG_PARA_HEADER, Tag ID: 0x050)

| 오프셋 | 자료형 | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | UINT32 | 4 | 문단 내용의 글자 수 (nchars) | |
| 4 | UINT32 | 4 | 컨트롤 마스크 | |
| 8 | UINT16 | 2 | 문단 모양 ID 참조값 | |
| 10 | UINT8 | 1 | 문단 스타일 ID 참조값 | |
| 11 | UINT8 | 1 | 단 나누기 종류 (구역, 쪽, 단 나누기 등) | |
| 12 | UINT16 | 2 | 글자 모양 정보 수 (Shape buffer 개수) | |
| 14 | UINT16 | 2 | Range Tag 정보 수 | |
| 16 | UINT16 | 2 | 각 줄에 대한 align 정보 수 | |
| 18 | UINT32 | 4 | 문단 Instance ID (unique ID) | |
| **총 길이** | | **24** | | |

#### 3.2. 컨트롤 헤더 (HWPTAG_CTRL_HEADER, Tag ID: 0x055)

| 오프셋 | 자료형 | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | UINT32 | **4** | **컨트롤 ID (Ctrl ID)** | |
| **총 길이** | | **4** | | |

#### 3.3. 문단 리스트 헤더 (HWPTAG_LIST_HEADER, Tag ID: 0x056)

| 오프셋 | 자료형 | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | INT16 | 2 | 문단 수 | |
| 2 | UINT32 | 4 | 속성 (텍스트 방향, 줄바꿈, 세로 정렬 등) | |
| **총 길이** | | **6** | | |

---

## III. 글 문서 파일 형식 3.x (순차적 바이너리 기반)

HWP 3.x 형식은 파일 전체 내용을 순차적으로 읽을 수 있으며, 두 바이트 이상 자료형은 **리틀 인디언** 형태입니다.

### 1. 주요 구조 영역 (Overall Structure)

| 영역 | 길이 (Bytes) | 압축 여부 | 시작 오프셋 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 파일 인식 정보 | **30** | 비압축 | 0 | |
| 문서 정보 | **128** | 비압축 | 30 | |
| 문서 요약 | **1008** | 비압축 | 158 | |
| 글꼴 이름 | 가변 | 압축(√) | 가변 | |
| 문단 리스트 | 가변 | 압축(√) | 가변 | |

### 2. 문서 정보 (Offset 30부터, 총 128 Bytes)

| 오프셋 | 자료형 | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | word | 2 | 커서 줄 (문단 번호) | |
| 4 | byte | 1 | 용지 종류 | |
| 6 | hunit | 2 | 용지 길이 (1/1800인치) | |
| 10 | hunit | 2 | 위쪽 여백 | |
| 24 | dword | 4 | 문서 보호 (1=보호된 문서) | |
| 124 | byte | 1 | **압축 플래그** (0 = 압축 안 됨) | |
| 126 | word | 2 | 정보 블록 길이 | |
| **총 길이** | | **128** | | |

### 3. 문단 정보 (Para Information)

문단 정보의 전체 길이는 `앞 문단 모양` 플래그(Offset 0)에 따라 **43 바이트** 또는 **230 바이트**로 달라집니다.

| 오프셋 | 자료형 | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | byte | 1 | 앞 문단 모양 플래그 (0일 때만 문단 모양(187B) 저장) | |
| 1 | word | 2 | 글자 수 (hchar 단위, 0이면 문단 리스트 끝) | |
| 3 | word | 2 | 줄 수 | |
| 7 | dword | 4 | 특수 문자 플래그 (0-31 특수 문자 존재 여부) | |
| 12 | {글자 모양} | **31** | 대표 글자 모양 (Offset 12부터 31B) | |
| 43 | {문단 모양} | **187** | 문단 모양 (앞 문단 모양이 0일 때만 저장) | |

### 4. 글자 모양 (Char Shape, 총 31 Bytes)

| 오프셋 | 자료형 | 길이 (Bytes) | 설명 | 참조 |
| :--- | :--- | :--- | :--- | :--- |
| 0 | hunit | 2 | 크기 | |
| 2 | byte array | 7 | 언어별 글꼴 인덱스 (7개 언어) | |
| 9 | byte array | 7 | 언어별 장평 (50% ~ 200%) | |
| 16 | sbyte array | 7 | 언어별 자간 (-50% ~ 50%) | |
| 26 | byte | 1 | 속성 (이탤릭, 진하게, 밑줄 등) | |
| **총 길이** | | **31** | | |

---

### IV. HWPML (XML 기반) 주요 단위

HWPML은 XML 기반이므로 바이트 길이는 가변적이지만, 속성 값의 단위가 중요합니다.

| 단위 형식 | 설명 | 참조 |
| :--- | :--- | :--- |
| **[hwpunit]** | 1/7200인치 단위로 표현 (5.0 형식과 동일) | |
| **[RGB-Color]** | 0x00bbggrr 형식의 십진수 RGB 값 | |
| **[LangType]** | 언어 종류 (Hangul, Latin, Hanja, Japanese, Other, Symbol, User) | |
| **[AlignmentType1]** | 정렬 방식 (Justify, Left, Right, Center, Distribute, DistributeSpace) | |

---
---

## HWP 문서 파일 형식 구조 다운로드

프로그램 개발에 사용하실 수 있도록 위의 분석 내용을 마크다운 파일로 제공합니다. 아래 코드를 복사하여 `.md` 확장자로 저장하시면 됩니다.

<br>

# HWP File Format Specification for Developers

## I. Common Data Types (Data Types)

| Type | Length (Bytes) | HWP Version | Description |
| :--- | :--- | :--- | :--- |
| **BYTE** (UINT8) | 1 | 5.0 | Unsigned 8-bit integer (0 ~ 255) |
| **WORD** (UINT16) | 2 | 5.0 | Unsigned 16-bit integer |
| **DWORD** (UINT32) | 4 | 5.0 | Unsigned 32-bit integer (Little-endian) |
| **WCHAR** | 2 | 5.0 | Unicode character (UTF-16LE) |
| **HWPUNIT** (UINT32) | 4 | 5.0 | HWP internal unit (1/7200 inch, unsigned) |
| **SHWPUNIT** (INT32) | 4 | 5.0 | HWP internal unit (1/7200 inch, signed) |
| **COLORREF** | 4 | 5.0 | RGB value (0x00bbggrr) |
| **hchar** | 2 | 3.x | HWP internal character code (2 bytes fixed) |
| **hunit** | 2 | 3.x | HWP internal unit (1/1800 inch) |
| **dword** | 4 | 3.x | 32-bit unsigned long |

---

## II. HWP 5.0 File Structure (Compound File / Record Based)

Records start with a 32-bit header (Tag ID, Level, Size).

### 1. FileHeader Stream (Fixed Length: 256 Bytes)

| Offset | Type | Length (Bytes) | Description |
| :--- | :--- | :--- | :--- |
| 0 | BYTE array | **32** | Signature: "HWP Document File" |
| 32 | DWORD | **4** | File Version (0xMMnnPPrr) |
| 36 | DWORD | **4** | Properties (Compression, Encryption flags) |
| 48 | BYTE | **1** | KOGL License supported country code |
| 49 | BYTE array | **207** | Reserved |
| **Total** | | **256** | |

### 2. DocInfo Stream: Key Records

| Record Name | Tag ID (Hex) | Min. Length (Bytes) | Key Data Types |
| :--- | :--- | :--- | :--- |
| **HWPTAG_DOCUMENT_PROPERTIES** | 0x010 | **26** | 7x UINT16 (Start numbers) + 3x UINT32 (Caret position) |
| **HWPTAG_ID_MAPPINGS** | 0x011 | **72** | INT32 array (Mapping counts) |
| **HWPTAG_CHAR_SHAPE** | 0x015 | **72** | 7x WORD (Font ID) + 4x 7x (U/I)INT8 (Ratios) + INT32 (Size) + UINT32 (Properties) |

### 3. BodyText Stream: Paragraph Records

| Record Name | Tag ID (Hex) | Min. Length (Bytes) | Key Data Types |
| :--- | :--- | :--- | :--- |
| **HWPTAG_PARA_HEADER** | 0x050 | **24** | 2x UINT32 (Chars, Control Mask) + 3x UINT16 (Counts) + 2x UINT8 (Style/Div) + UINT32 (Instance ID) |
| **HWPTAG_PARA_TEXT** | 0x051 | **Variable** | WCHAR array (2 * nchars) |
| **HWPTAG_CTRL_HEADER** | 0x055 | **4** | UINT32 (Control ID) |
| **HWPTAG_LIST_HEADER** | 0x056 | **6** | INT16 (Paragraph Count) + UINT32 (Properties) |

---

## III. HWP 3.x File Structure (Sequential Binary Based)

### 1. Overall Structure & Compression

The main content (`글꼴 이름` through `추가 정보 블록 (#1)`) is typically stored as a single **compressed stream** (using gzip) if the compression flag (Offset 124 in Document Info) is set.

### 2. Document Information (Offset 30, Total 128 Bytes)

| Offset | Type | Length (Bytes) | Description |
| :--- | :--- | :--- | :--- |
| 0 | word | 2 | Cursor Line (Paragraph number) |
| 4 | byte | 1 | Paper Type |
| 6 | hunit | 2 | Paper Length (1/1800 inch) |
| 24 | dword | 4 | Document Protection Flag |
| 124 | byte | 1 | **Compression Flag** (0=None) |
| 126 | word | 2 | Information Block Length |

### 3. Paragraph Information (Para Information)

Length is **43 bytes** or **230 bytes** depending on the flag at Offset 0.

| Offset | Type | Length (Bytes) | Description |
| :--- | :--- | :--- | :--- |
| 0 | byte | 1 | Follow Previous ParaShape Flag (0=New ParaShape saved) |
| 1 | word | 2 | Character count (hchar units) |
| 7 | dword | 4 | Control Character Flag (Bitmask for controls 0-31) |
| 12 | {Char Shape} | **31** | Default character shape structure |
| 43 | {Para Shape} | **187** | Paragraph shape (Only if flag at Offset 0 is 0) |

---
